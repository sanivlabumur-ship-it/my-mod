package com.digersto.registry;

import com.digersto.DigerstoMod;
import com.digersto.block.GasVentBlock;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, DigerstoMod.MODID);

    public static final RegistryObject<Block> GAS_VENT = BLOCKS.register("gas_vent", GasVentBlock::new);
}
