package com.digersto.registry;

import com.digersto.DigerstoMod;
import com.digersto.item.FilterItem;
import com.digersto.item.GasMaskItem;
import com.digersto.item.MaskCondition;
import com.digersto.item.MaskType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.Map;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, DigerstoMod.MODID);

    /** Ключ: "gp_5", "gp_5_new", "gp_5_rotten" и т.д. */
    public static final Map<String, RegistryObject<Item>> MASKS = new LinkedHashMap<>();

    static {
        for (MaskType type : MaskType.values()) {
            for (MaskCondition cond : MaskCondition.values()) {
                String id = type.id + cond.suffix;
                MASKS.put(id, ITEMS.register(id, () -> new GasMaskItem(type.tier, cond, type.wideView)));
            }
        }
    }

    public static final RegistryObject<Item> FILTER = ITEMS.register("filter", () -> new FilterItem(false));
    public static final RegistryObject<Item> FILTER_ROTTEN = ITEMS.register("filter_rotten", () -> new FilterItem(true));

    public static final RegistryObject<Item> GAS_VENT = ITEMS.register("gas_vent",
            () -> new BlockItem(ModBlocks.GAS_VENT.get(), new Item.Properties()));

    public static final RegistryObject<Item> GUARD_EGG = ITEMS.register("guard_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.GUARD, 0x1E2850, 0xC8C83C, new Item.Properties()));
    public static final RegistryObject<Item> POLICE_EGG = ITEMS.register("police_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.POLICE, 0x28468C, 0xDCDCE6, new Item.Properties()));
    public static final RegistryObject<Item> FBI_EGG = ITEMS.register("fbi_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.FBI, 0x121214, 0xEBC828, new Item.Properties()));
    public static final RegistryObject<Item> DIGERSTO_EGG = ITEMS.register("digersto_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.DIGERSTO, 0x326E3C, 0x2D3C28, new Item.Properties()));

    public static Item mask(String id) {
        return MASKS.get(id).get();
    }
}
