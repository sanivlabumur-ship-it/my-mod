package com.digersto.registry;

import com.digersto.DigerstoMod;
import com.digersto.entity.DigerstoEntity;
import com.digersto.entity.FbiEntity;
import com.digersto.entity.GuardEntity;
import com.digersto.entity.PoliceEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, DigerstoMod.MODID);

    public static final RegistryObject<EntityType<GuardEntity>> GUARD = ENTITIES.register("guard",
            () -> EntityType.Builder.of(GuardEntity::new, MobCategory.MISC).sized(0.6F, 1.95F).clientTrackingRange(8).build("guard"));

    public static final RegistryObject<EntityType<PoliceEntity>> POLICE = ENTITIES.register("police",
            () -> EntityType.Builder.of(PoliceEntity::new, MobCategory.MISC).sized(0.6F, 1.95F).clientTrackingRange(8).build("police"));

    public static final RegistryObject<EntityType<FbiEntity>> FBI = ENTITIES.register("fbi",
            () -> EntityType.Builder.of(FbiEntity::new, MobCategory.MISC).sized(0.6F, 1.95F).clientTrackingRange(8).build("fbi"));

    public static final RegistryObject<EntityType<DigerstoEntity>> DIGERSTO = ENTITIES.register("digersto",
            () -> EntityType.Builder.of(DigerstoEntity::new, MobCategory.MISC).sized(0.6F, 1.95F).clientTrackingRange(8).build("digersto"));
}
