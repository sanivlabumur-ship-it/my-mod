package com.digersto.registry;

import com.digersto.DigerstoMod;
import com.digersto.world.SiteFeature;
import com.digersto.world.SiteKind;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModFeatures {
    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(ForgeRegistries.FEATURES, DigerstoMod.MODID);

    static {
        for (SiteKind kind : SiteKind.values()) {
            FEATURES.register(kind.id, () -> new SiteFeature(kind));
        }
    }
}
