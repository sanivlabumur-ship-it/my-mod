package com.digersto.item;

import com.digersto.DigerstoMod;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

public class MaskMaterial implements ArmorMaterial {
    private final MaskTier tier;
    private final MaskCondition condition;

    public MaskMaterial(MaskTier tier, MaskCondition condition) {
        this.tier = tier;
        this.condition = condition;
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return Math.max(10, (int) (tier.baseDurability * condition.durabilityFactor));
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return tier.armor;
    }

    @Override
    public int getEnchantmentValue() {
        return 5;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ARMOR_EQUIP_LEATHER;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.EMPTY;
    }

    /** Текстура слоя: assets/digersto/textures/models/armor/<tier>_<condition>_layer_1.png */
    @Override
    public String getName() {
        return DigerstoMod.MODID + ":" + tier.name().toLowerCase() + "_" + condition.name().toLowerCase();
    }

    @Override
    public float getToughness() {
        return 0F;
    }

    @Override
    public float getKnockbackResistance() {
        return 0F;
    }
}
