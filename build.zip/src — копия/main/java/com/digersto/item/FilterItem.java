package com.digersto.item;

import net.minecraft.world.item.Item;

public class FilterItem extends Item {
    public final boolean rotten;

    public FilterItem(boolean rotten) {
        super(new Item.Properties().durability(rotten ? 300 : 900));
        this.rotten = rotten;
    }
}
