package com.digersto.item;

import com.digersto.DigerstoMod;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import javax.annotation.Nullable;

import java.util.List;

public class GasMaskItem extends ArmorItem {
    public final MaskTier tier;
    public final MaskCondition condition;
    public final boolean wideView;

    public GasMaskItem(MaskTier tier, MaskCondition condition, boolean wideView) {
        super(new MaskMaterial(tier, condition), ArmorItem.Type.HELMET, new Item.Properties());
        this.tier = tier;
        this.condition = condition;
        this.wideView = wideView;
    }

    @Override
    public void onArmorTick(ItemStack stack, Level level, Player player) {
        if (wideView && condition != MaskCondition.ROTTEN && !level.isClientSide && player.tickCount % 40 == 0) {
            player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 260, 0, false, false, false));
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip." + DigerstoMod.MODID + ".tier." + tier.name().toLowerCase()));
        if (wideView) {
            tooltip.add(Component.translatable("tooltip." + DigerstoMod.MODID + ".wide"));
        }
    }

    /**
     * Вызывается, когда на игрока действует газ. true - газ не подействовал.
     * Гнилой противогаз и гнилой фильтр иногда пропускают газ.
     */
    public static boolean tryProtect(Player player) {
        ItemStack head = player.getItemBySlot(EquipmentSlot.HEAD);
        if (!(head.getItem() instanceof GasMaskItem mask)) {
            return false;
        }
        RandomSource r = player.getRandom();
        if (mask.condition == MaskCondition.ROTTEN && r.nextFloat() < 0.30F) {
            return false;
        }
        if (mask.tier == MaskTier.ISOLATING) {
            head.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(EquipmentSlot.HEAD));
            return true;
        }
        ItemStack filter = findFilter(player);
        if (filter.isEmpty()) {
            return false;
        }
        boolean rotten = ((FilterItem) filter.getItem()).rotten;
        filter.hurtAndBreak(1, player, p -> {});
        if (r.nextInt(5) == 0) {
            head.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(EquipmentSlot.HEAD));
        }
        return !(rotten && r.nextFloat() < 0.40F);
    }

    private static ItemStack findFilter(Player player) {
        ItemStack rottenFound = ItemStack.EMPTY;
        for (ItemStack s : player.getInventory().items) {
            if (s.getItem() instanceof FilterItem f) {
                if (!f.rotten) return s;
                if (rottenFound.isEmpty()) rottenFound = s;
            }
        }
        for (ItemStack s : player.getInventory().offhand) {
            if (s.getItem() instanceof FilterItem f) {
                if (!f.rotten) return s;
                if (rottenFound.isEmpty()) rottenFound = s;
            }
        }
        return rottenFound;
    }
}
