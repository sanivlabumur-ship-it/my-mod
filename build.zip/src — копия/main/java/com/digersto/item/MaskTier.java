package com.digersto.item;

public enum MaskTier {
    SIMPLE(150, 1),
    MILITARY(300, 2),
    ISOLATING(200, 2);

    public final int baseDurability;
    public final int armor;

    MaskTier(int baseDurability, int armor) {
        this.baseDurability = baseDurability;
        this.armor = armor;
    }
}
