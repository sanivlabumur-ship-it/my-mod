package com.digersto.item;

/** Все модели противогазов (СССР/Россия и США). Чтобы добавить новую - допиши строку и ресурсы. */
public enum MaskType {
    GP_4("gp_4", MaskTier.SIMPLE, false),
    GP_5("gp_5", MaskTier.SIMPLE, false),
    GP_5M("gp_5m", MaskTier.MILITARY, false),
    GP_7("gp_7", MaskTier.MILITARY, true),
    GP_7V("gp_7v", MaskTier.MILITARY, true),
    GP_7VM("gp_7vm", MaskTier.MILITARY, true),
    GP_9("gp_9", MaskTier.MILITARY, true),
    GP_21("gp_21", MaskTier.MILITARY, true),
    PMK("pmk", MaskTier.MILITARY, false),
    PMK_1("pmk_1", MaskTier.MILITARY, false),
    PMK_2("pmk_2", MaskTier.MILITARY, false),
    PMK_3("pmk_3", MaskTier.MILITARY, false),
    SHM_41M("shm_41m", MaskTier.MILITARY, false),
    SHS_1("shs_1", MaskTier.MILITARY, false),
    PBF("pbf", MaskTier.SIMPLE, false),
    RPG_67("rpg_67", MaskTier.MILITARY, false),
    IP_4("ip_4", MaskTier.ISOLATING, false),
    IP_5("ip_5", MaskTier.ISOLATING, false),
    KIP_8("kip_8", MaskTier.ISOLATING, false),
    PDF_D("pdf_d", MaskTier.SIMPLE, false),
    PDF_SH("pdf_sh", MaskTier.SIMPLE, false),
    M17("m17", MaskTier.MILITARY, false),
    M17A1("m17a1", MaskTier.MILITARY, false),
    M17A2("m17a2", MaskTier.MILITARY, false),
    M40("m40", MaskTier.MILITARY, true),
    M42("m42", MaskTier.MILITARY, false),
    M45("m45", MaskTier.MILITARY, false),
    M50("m50", MaskTier.MILITARY, false),
    M51("m51", MaskTier.MILITARY, false),
    MCU_2P("mcu_2p", MaskTier.MILITARY, true),
    MARK_IV("mark_iv", MaskTier.SIMPLE, false);

    public final String id;
    public final MaskTier tier;
    /** Широкий обзор: даёт ночное зрение, пока надет (не у гнилых). */
    public final boolean wideView;

    MaskType(String id, MaskTier tier, boolean wideView) {
        this.id = id;
        this.tier = tier;
        this.wideView = wideView;
    }
}
