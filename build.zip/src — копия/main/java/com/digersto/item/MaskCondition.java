package com.digersto.item;

public enum MaskCondition {
    NEW("_new", 1.0F),
    NORMAL("", 0.6F),
    ROTTEN("_rotten", 0.25F);

    public final String suffix;
    public final float durabilityFactor;

    MaskCondition(String suffix, float durabilityFactor) {
        this.suffix = suffix;
        this.durabilityFactor = durabilityFactor;
    }
}
