package com.digersto;

import com.digersto.entity.GuardEntity;
import com.digersto.entity.PoliceEntity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

/**
 * Шкала розыска 0-5. Растёт, когда ЧОП вызывает наряд и когда игрок убивает охрану или полицию.
 * Падает на 1 раз в минуту. С 2 звезды приезжает больше людей, с 4 - всегда ФБР.
 */
@Mod.EventBusSubscriber(modid = DigerstoMod.MODID)
public class Wanted {
    public static final int MAX = 5;
    private static final String LEVEL = "digersto_wanted";
    private static final String TIMER = "digersto_wanted_timer";

    public static int get(Player p) {
        return p.getPersistentData().getInt(LEVEL);
    }

    public static void add(Player p, int n) {
        CompoundTag d = p.getPersistentData();
        d.putInt(LEVEL, Math.min(MAX, d.getInt(LEVEL) + n));
        d.putInt(TIMER, 0);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.SERVER) return;
        Player p = e.player;
        if (p.tickCount % 20 != 0) return;
        CompoundTag d = p.getPersistentData();
        int lvl = d.getInt(LEVEL);
        if (lvl <= 0) return;
        int t = d.getInt(TIMER) + 1;
        if (t >= 60) {
            lvl--;
            t = 0;
            d.putInt(LEVEL, lvl);
        }
        d.putInt(TIMER, t);
        if (lvl > 0) {
            String stars = "\u2605".repeat(lvl) + "\u2606".repeat(MAX - lvl);
            p.displayClientMessage(Component.translatable("message." + DigerstoMod.MODID + ".wanted", stars), true);
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer dead) {
            dead.getPersistentData().putInt(LEVEL, 0);
            return;
        }
        if ((e.getEntity() instanceof GuardEntity || e.getEntity() instanceof PoliceEntity)
                && e.getSource().getEntity() instanceof ServerPlayer killer) {
            add(killer, 1);
        }
    }
}
