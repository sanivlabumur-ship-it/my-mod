package com.digersto.block;

import com.digersto.item.GasMaskItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.AABB;

/** Газовый очаг: раз в секунду травит игроков рядом, если на них нет рабочего противогаза. */
public class GasVentBlock extends Block {
    private static final double RADIUS = 6.0D;

    public GasVentBlock() {
        super(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).strength(1.5F).sound(SoundType.METAL));
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean moved) {
        if (!level.isClientSide) {
            level.scheduleTick(pos, this, 20);
        }
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        AABB box = new AABB(pos).inflate(RADIUS, 2.0D, RADIUS);
        for (Player p : level.getEntitiesOfClass(Player.class, box)) {
            if (p.isCreative() || p.isSpectator()) continue;
            if (!GasMaskItem.tryProtect(p)) {
                p.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 0));
                p.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200, 0));
            }
        }
        level.scheduleTick(pos, this, 20);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(3) == 0) {
            level.addParticle(ParticleTypes.LARGE_SMOKE,
                    pos.getX() + 0.5D + (random.nextDouble() - 0.5D) * 0.6D,
                    pos.getY() + 1.0D,
                    pos.getZ() + 0.5D + (random.nextDouble() - 0.5D) * 0.6D,
                    0.0D, 0.04D, 0.0D);
        }
    }
}
