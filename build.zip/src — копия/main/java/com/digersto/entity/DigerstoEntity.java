package com.digersto.entity;

import com.digersto.item.GasMaskItem;
import com.digersto.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.Container;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.EnumSet;

/** Дигерсто: лазит по объектам, тащит противогазы из сундуков и убегает от игроков. Убей - получишь добычу. */
public class DigerstoEntity extends PathfinderMob {

    public DigerstoEntity(EntityType<? extends DigerstoEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 16.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.33D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new AvoidEntityGoal<>(this, Player.class, 10.0F, 1.1D, 1.4D));
        this.goalSelector.addGoal(2, new StealMaskGoal(this));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType type,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, type, data, tag);
        this.setItemSlot(EquipmentSlot.HEAD, new ItemStack(ModItems.mask("gp_5")));
        this.setDropChance(EquipmentSlot.HEAD, 0.0F);
        return result;
    }

    /** Пока тащит добычу - не пропадает. */
    @Override
    public boolean removeWhenFarAway(double distance) {
        return this.getMainHandItem().isEmpty();
    }

    // ------------------------------------------------------------------
    static class StealMaskGoal extends Goal {
        private static final int RADIUS = 12;

        private final DigerstoEntity mob;
        private BlockPos target;
        private int timeout;

        StealMaskGoal(DigerstoEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (!mob.getMainHandItem().isEmpty()) return false;
            if (mob.getRandom().nextInt(40) != 0) return false;
            target = findTarget();
            return target != null;
        }

        @Override
        public boolean canContinueToUse() {
            return target != null && mob.getMainHandItem().isEmpty() && timeout > 0;
        }

        @Override
        public void start() {
            timeout = 400;
            moveToTarget();
        }

        @Override
        public void stop() {
            target = null;
            mob.getNavigation().stop();
        }

        @Override
        public void tick() {
            timeout--;
            if (mob.distanceToSqr(Vec3.atCenterOf(target)) < 6.25D) {
                steal();
                target = null;
                return;
            }
            if (mob.getNavigation().isDone()) {
                moveToTarget();
            }
        }

        private void moveToTarget() {
            mob.getNavigation().moveTo(target.getX() + 0.5D, target.getY(), target.getZ() + 0.5D, 1.0D);
        }

        private void steal() {
            BlockEntity be = mob.level().getBlockEntity(target);
            if (be instanceof Container container) {
                for (int i = 0; i < container.getContainerSize(); i++) {
                    if (container.getItem(i).getItem() instanceof GasMaskItem) {
                        ItemStack taken = container.removeItem(i, 1);
                        container.setChanged();
                        mob.setItemSlot(EquipmentSlot.MAINHAND, taken);
                        mob.setDropChance(EquipmentSlot.MAINHAND, 2.0F); // всегда выпадет при смерти
                        mob.playSound(SoundEvents.VILLAGER_YES, 1.0F, 1.3F);
                        return;
                    }
                }
            }
        }

        @Nullable
        private BlockPos findTarget() {
            Level level = mob.level();
            BlockPos origin = mob.blockPosition();
            int minCx = (origin.getX() - RADIUS) >> 4;
            int maxCx = (origin.getX() + RADIUS) >> 4;
            int minCz = (origin.getZ() - RADIUS) >> 4;
            int maxCz = (origin.getZ() + RADIUS) >> 4;
            for (int cx = minCx; cx <= maxCx; cx++) {
                for (int cz = minCz; cz <= maxCz; cz++) {
                    LevelChunk chunk = level.getChunkSource().getChunkNow(cx, cz);
                    if (chunk == null) continue;
                    for (BlockEntity be : chunk.getBlockEntities().values()) {
                        if (!(be instanceof Container container)) continue;
                        if (be.getBlockPos().distSqr(origin) > RADIUS * RADIUS) continue;
                        for (int i = 0; i < container.getContainerSize(); i++) {
                            if (container.getItem(i).getItem() instanceof GasMaskItem) {
                                return be.getBlockPos();
                            }
                        }
                    }
                }
            }
            return null;
        }
    }
}
