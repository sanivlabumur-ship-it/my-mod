package com.digersto.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** Агент ФБР: то же, что полицейский, но сильнее. Приезжает на военные объекты. */
public class FbiEntity extends PoliceEntity {
    public FbiEntity(EntityType<? extends FbiEntity> type, Level level) {
        super(type, level);
    }
}
