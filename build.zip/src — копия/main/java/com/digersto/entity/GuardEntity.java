package com.digersto.entity;

import com.digersto.DigerstoMod;
import com.digersto.Wanted;
import com.digersto.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.MoveTowardsRestrictionGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap;

import javax.annotation.Nullable;

/** ЧОП: сидит у своей будки, замечает игрока и через пару секунд вызывает полицию (или ФБР на военных объектах). */
public class GuardEntity extends PathfinderMob {
    private static final int CALL_DELAY_TICKS = 80;

    private boolean military = false;
    private boolean called = false;
    private int callTicks = -1;

    public GuardEntity(EntityType<? extends GuardEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 24.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                .add(Attributes.FOLLOW_RANGE, 20.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.1D, false));
        this.goalSelector.addGoal(3, new MoveTowardsRestrictionGoal(this, 0.8D));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.5D));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 10.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
        // Крадущегося игрока охранник замечает только вблизи
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false,
                e -> !(e.isCrouching() && e.distanceToSqr(this) > 36.0D)));
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType type,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, type, data, tag);
        this.restrictTo(this.blockPosition(), 8);
        this.setPersistenceRequired();
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.STICK)); // "дубинка"
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        return result;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void setTarget(@Nullable LivingEntity target) {
        super.setTarget(target);
        if (target != null && !called && callTicks < 0 && !this.level().isClientSide) {
            callTicks = CALL_DELAY_TICKS;
            this.playSound(SoundEvents.NOTE_BLOCK_FLUTE.value(), 3.0F, 2.0F); // свисток
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide || callTicks <= 0) {
            return;
        }
        callTicks--;
        if (callTicks == 0) {
            LivingEntity target = this.getTarget();
            // Если охранника вырубили или игрок скрылся из виду - вызов не состоится
            if (target != null && this.isAlive() && this.level() instanceof ServerLevel sl) {
                callPolice(sl, target);
                called = true;
            } else {
                callTicks = -1;
            }
        }
    }

    private void callPolice(ServerLevel level, LivingEntity target) {
        int wanted = target instanceof Player tp ? Wanted.get(tp) : 0;
        boolean fbi = military || wanted >= 4;
        int count = (fbi ? 3 : 2) + (wanted >= 2 ? 1 : 0);
        for (int i = 0; i < count; i++) {
            PoliceEntity cop;
            if (fbi) {
                cop = ModEntities.FBI.get().create(level);
            } else {
                cop = ModEntities.POLICE.get().create(level);
            }
            if (cop == null) continue;
            int dx = this.random.nextInt(25) - 12;
            int dz = this.random.nextInt(25) - 12;
            BlockPos p = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, this.blockPosition().offset(dx, 0, dz));
            cop.moveTo(p.getX() + 0.5D, p.getY(), p.getZ() + 0.5D, this.random.nextFloat() * 360.0F, 0.0F);
            cop.setTarget(target);
            level.addFreshEntity(cop);
        }
        level.playSound(null, this.blockPosition(), SoundEvents.NOTE_BLOCK_FLUTE.value(), SoundSource.HOSTILE, 3.0F, 2.0F);
        if (target instanceof Player player) {
            Wanted.add(player, 1);
            player.displayClientMessage(Component.translatable("message." + DigerstoMod.MODID + (fbi ? ".fbi" : ".police")), true);
        }
    }

    public boolean isMilitary() {
        return military;
    }

    public void setMilitary(boolean military) {
        this.military = military;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Military", military);
        tag.putBoolean("Called", called);
        if (this.hasRestriction()) {
            BlockPos c = this.getRestrictCenter();
            tag.putInt("HomeX", c.getX());
            tag.putInt("HomeY", c.getY());
            tag.putInt("HomeZ", c.getZ());
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        military = tag.getBoolean("Military");
        called = tag.getBoolean("Called");
        if (tag.contains("HomeX")) {
            this.restrictTo(new BlockPos(tag.getInt("HomeX"), tag.getInt("HomeY"), tag.getInt("HomeZ")), 8);
        }
    }
}
