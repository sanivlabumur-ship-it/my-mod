package com.digersto;

import com.digersto.entity.DigerstoEntity;
import com.digersto.entity.FbiEntity;
import com.digersto.entity.GuardEntity;
import com.digersto.entity.PoliceEntity;
import com.digersto.registry.ModBlocks;
import com.digersto.registry.ModEntities;
import com.digersto.registry.ModFeatures;
import com.digersto.registry.ModItems;
import com.digersto.registry.ModTabs;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(DigerstoMod.MODID)
public class DigerstoMod {
    public static final String MODID = "digersto";

    public DigerstoMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModFeatures.FEATURES.register(bus);
        ModTabs.TABS.register(bus);
        bus.addListener(this::registerAttributes);
    }

    private void registerAttributes(EntityAttributeCreationEvent e) {
        e.put(ModEntities.GUARD.get(), GuardEntity.createAttributes().build());
        e.put(ModEntities.POLICE.get(), PoliceEntity.createAttributes().build());
        e.put(ModEntities.FBI.get(), PoliceEntity.createFbiAttributes().build());
        e.put(ModEntities.DIGERSTO.get(), DigerstoEntity.createAttributes().build());
    }
}
