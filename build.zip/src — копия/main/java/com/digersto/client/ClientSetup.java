package com.digersto.client;

import com.digersto.DigerstoMod;
import com.digersto.entity.DigerstoEntity;
import com.digersto.entity.FbiEntity;
import com.digersto.entity.GuardEntity;
import com.digersto.entity.PoliceEntity;
import com.digersto.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = DigerstoMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.GUARD.get(), ctx -> new SimpleHumanoidRenderer<GuardEntity>(ctx, "guard"));
        e.registerEntityRenderer(ModEntities.POLICE.get(), ctx -> new SimpleHumanoidRenderer<PoliceEntity>(ctx, "police"));
        e.registerEntityRenderer(ModEntities.FBI.get(), ctx -> new SimpleHumanoidRenderer<FbiEntity>(ctx, "fbi"));
        e.registerEntityRenderer(ModEntities.DIGERSTO.get(), ctx -> new SimpleHumanoidRenderer<DigerstoEntity>(ctx, "digersto"));
    }
}
