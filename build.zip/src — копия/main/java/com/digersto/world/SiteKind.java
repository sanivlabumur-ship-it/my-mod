package com.digersto.world;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

/**
 * Типы объектов. Заброшки (guarded=false): никто не охраняет, но внутри газовые очаги.
 * Охраняемые (guarded=true): забор, будка и ЧОП, а на военных объектах после вызова приезжает ФБР.
 *
 * Размеры (w, d) вместе с забором (4 блока с каждой стороны) должны быть не больше ~30 блоков,
 * иначе постройка выйдет за пределы чанков, доступных при генерации.
 */
public enum SiteKind {
    //          id                w   d   h   wall                       alt                          floor                  guarded military guards chests vents loot
    SCHOOL(     "school",        17,  9, 4, Blocks.BRICKS,              Blocks.STONE_BRICKS,         Blocks.SMOOTH_STONE,   false,  false,   0,     2,     2,    "abandoned"),
    HOSPITAL(   "hospital",      15, 11, 4, Blocks.SMOOTH_QUARTZ,       Blocks.STONE_BRICKS,         Blocks.SMOOTH_STONE,   false,  false,   0,     2,     2,    "abandoned"),
    FACTORY(    "factory",       21, 13, 6, Blocks.COBBLESTONE,         Blocks.MOSSY_COBBLESTONE,    Blocks.STONE,          false,  false,   0,     3,     3,    "abandoned"),
    SHELTER(    "shelter",        9,  9, 3, Blocks.STONE_BRICKS,        Blocks.CRACKED_STONE_BRICKS, Blocks.STONE_BRICKS,   false,  false,   0,     1,     1,    "abandoned"),
    FIRE_STATION("fire_station", 15,  9, 5, Blocks.BRICKS,              Blocks.STONE_BRICKS,         Blocks.SMOOTH_STONE,   true,   false,   1,     2,     0,    "guarded_basic"),
    MILITARY(   "military",      17, 11, 4, Blocks.POLISHED_ANDESITE,   Blocks.ANDESITE,            Blocks.STONE,          true,   true,    2,     3,     0,    "guarded_military"),
    GUARDED_HOSPITAL("guarded_hospital", 13, 9, 4, Blocks.SMOOTH_QUARTZ, Blocks.QUARTZ_BRICKS,      Blocks.SMOOTH_STONE,   true,   false,   1,     2,     0,    "guarded_military");

    public final String id;
    public final int w, d, h;
    public final Block wall, alt, floor;
    public final boolean guarded, military;
    public final int guards, chests, vents;
    public final String loot;

    SiteKind(String id, int w, int d, int h, Block wall, Block alt, Block floor,
             boolean guarded, boolean military, int guards, int chests, int vents, String loot) {
        this.id = id;
        this.w = w;
        this.d = d;
        this.h = h;
        this.wall = wall;
        this.alt = alt;
        this.floor = floor;
        this.guarded = guarded;
        this.military = military;
        this.guards = guards;
        this.chests = chests;
        this.vents = vents;
        this.loot = loot;
    }
}
