package com.digersto.world;

import com.digersto.DigerstoMod;
import com.digersto.entity.DigerstoEntity;
import com.digersto.entity.GuardEntity;
import com.digersto.registry.ModBlocks;
import com.digersto.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * Простая процедурная постройка (коробка с окнами, дверью, сундуками).
 * Заменить на красивые NBT-структуры можно позже - логика лута, охраны и газа от этого не зависит.
 */
public class SiteFeature extends Feature<NoneFeatureConfiguration> {
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private final SiteKind k;

    public SiteFeature(SiteKind kind) {
        super(NoneFeatureConfiguration.CODEC);
        this.k = kind;
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        RandomSource rand = ctx.random();
        BlockPos origin = ctx.origin();
        int w = k.w, d = k.d, h = k.h;
        int m = k.guarded ? 4 : 0;
        BlockPos c0 = origin.offset(-w / 2, 0, -d / 2);

        // Место должно быть более-менее ровным и не в воде
        int[][] corners = {{-m, -m}, {w + m - 1, -m}, {-m, d + m - 1}, {w + m - 1, d + m - 1}};
        for (int[] c : corners) {
            BlockPos p = level.getHeightmapPos(Heightmap.Types.WORLD_SURFACE_WG, c0.offset(c[0], 0, c[1]));
            if (Math.abs(p.getY() - origin.getY()) > 3) return false;
            if (!level.getFluidState(p.below()).isEmpty()) return false;
        }

        BlockState wall = k.wall.defaultBlockState();
        BlockState alt = k.alt.defaultBlockState();
        BlockState floor = k.floor.defaultBlockState();
        BlockState glass = Blocks.GLASS_PANE.defaultBlockState();

        // 1. Расчистка, фундамент и пол
        for (int x = -m; x < w + m; x++) {
            for (int z = -m; z < d + m; z++) {
                boolean inside = x >= 0 && x < w && z >= 0 && z < d;
                int top = inside ? h + 2 : 3;
                for (int y = 0; y <= top; y++) {
                    level.setBlock(c0.offset(x, y, z), AIR, 2);
                }
                for (int y = -1; y >= -4; y--) {
                    BlockPos p = c0.offset(x, y, z);
                    if (level.isEmptyBlock(p) || !level.getFluidState(p).isEmpty()) {
                        level.setBlock(p, Blocks.COBBLESTONE.defaultBlockState(), 2);
                    }
                }
                if (inside) {
                    level.setBlock(c0.offset(x, -1, z), floor, 2);
                }
            }
        }

        // 2. Стены, окна, дверь, крыша
        for (int x = 0; x < w; x++) {
            for (int z = 0; z < d; z++) {
                boolean edge = x == 0 || x == w - 1 || z == 0 || z == d - 1;
                boolean corner = (x == 0 || x == w - 1) && (z == 0 || z == d - 1);
                if (edge) {
                    for (int y = 0; y < h; y++) {
                        boolean door = z == d - 1 && Math.abs(x - w / 2) <= 1 && y < 2;
                        boolean window = !door && !corner && y >= 1 && y <= 2 && (x + z) % 4 == 0;
                        BlockState st;
                        if (door) {
                            st = AIR;
                        } else if (window) {
                            // у заброшек часть окон выбита
                            st = (!k.guarded && rand.nextBoolean()) ? AIR : glass;
                        } else {
                            st = rand.nextFloat() < 0.25F ? alt : wall;
                        }
                        level.setBlock(c0.offset(x, y, z), st, 2);
                    }
                }
                // крыша (в заброшках бывают дыры)
                if (k.guarded || rand.nextFloat() > 0.12F) {
                    level.setBlock(c0.offset(x, h, z), wall, 2);
                }
            }
        }

        // 2b. Перегородка с двумя проёмами делит здание на две части
        if (w >= 11 && d >= 9) {
            int pz = d / 2;
            for (int x = 1; x < w - 1; x++) {
                boolean doorway = x == w / 3 || x == 2 * w / 3;
                for (int y = 0; y < h; y++) {
                    if (doorway && y < 2) continue;
                    level.setBlock(c0.offset(x, y, pz), rand.nextFloat() < 0.2F ? alt : wall, 2);
                }
            }
        }

        // 3. Сундуки с лутом
        BlockState chest = Blocks.CHEST.defaultBlockState();
        for (int i = 0; i < k.chests; i++) {
            BlockPos p = c0.offset(2 + rand.nextInt(w - 4), 0, 2 + rand.nextInt(d - 4));
            if (!level.getBlockState(p).isAir()) continue;
            level.setBlock(p, chest.setValue(ChestBlock.FACING, Direction.Plane.HORIZONTAL.getRandomDirection(rand)), 2);
            RandomizableContainerBlockEntity.setLootTable(level, rand, p,
                    new ResourceLocation(DigerstoMod.MODID, "chests/" + k.loot));
        }

        // 3b. Мебель и мусор
        Block[] props = propsFor(k);
        for (int x = 1; x < w - 1; x++) {
            for (int z = 1; z < d - 1; z++) {
                if (z >= d - 2 && Math.abs(x - w / 2) <= 1) continue; // не загораживаем вход
                if (rand.nextFloat() < 0.07F) {
                    BlockPos p = c0.offset(x, 0, z);
                    if (level.getBlockState(p).isAir()) {
                        level.setBlock(p, props[rand.nextInt(props.length)].defaultBlockState(), 2);
                    }
                }
            }
        }

        // 4. Газовые очаги и паутина (заброшки)
        for (int i = 0; i < k.vents; i++) {
            BlockPos p = c0.offset(1 + rand.nextInt(w - 2), 0, 1 + rand.nextInt(d - 2));
            if (!level.getBlockState(p).isAir()) continue;
            level.setBlock(p, ModBlocks.GAS_VENT.get().defaultBlockState(), 2);
            level.scheduleTick(p, ModBlocks.GAS_VENT.get(), 20);
        }
        if (!k.guarded) {
            for (int x = 1; x < w - 1; x++) {
                for (int z = 1; z < d - 1; z++) {
                    if (rand.nextFloat() < 0.04F) {
                        BlockPos p = c0.offset(x, 1 + rand.nextInt(h - 1), z);
                        if (level.getBlockState(p).isAir()) {
                            level.setBlock(p, Blocks.COBWEB.defaultBlockState(), 2);
                        }
                    }
                }
            }
        }

        // 5. Охраняемые объекты: забор, будка, ЧОП
        if (k.guarded) {
            BlockState bars = Blocks.IRON_BARS.defaultBlockState();
            for (int x = -m; x < w + m; x++) {
                for (int z = -m; z < d + m; z++) {
                    boolean ring = x == -m || x == w + m - 1 || z == -m || z == d + m - 1;
                    boolean gate = z == d + m - 1 && Math.abs(x - w / 2) <= 1;
                    if (ring && !gate) {
                        level.setBlock(c0.offset(x, 0, z), bars, 2);
                        level.setBlock(c0.offset(x, 1, z), bars, 2);
                    }
                }
            }
            // будка 3x3 рядом с воротами, вход со стороны здания
            int bx = w / 2 + 2, bz = d;
            for (int x = 0; x < 3; x++) {
                for (int z = 0; z < 3; z++) {
                    boolean edge = x == 0 || x == 2 || z == 0 || z == 2;
                    for (int y = 0; y < 2; y++) {
                        BlockPos p = c0.offset(bx + x, y, bz + z);
                        if (edge) {
                            boolean opening = x == 0 && z == 1;            // дверной проём
                            boolean win = z == 2 && x == 1 && y == 1;       // окно на улицу
                            level.setBlock(p, opening ? AIR : (win ? glass : wall), 2);
                        }
                    }
                    level.setBlock(c0.offset(bx + x, 2, bz + z), wall, 2);
                }
            }
            for (int i = 0; i < k.guards; i++) {
                GuardEntity g = com.digersto.registry.ModEntities.GUARD.get().create(level.getLevel());
                if (g == null) continue;
                BlockPos gp = i == 0 ? c0.offset(bx + 1, 0, bz + 1) : c0.offset(w / 2 - 3, 0, d + 1);
                g.moveTo(gp.getX() + 0.5D, gp.getY(), gp.getZ() + 0.5D, rand.nextFloat() * 360.0F, 0.0F);
                g.setMilitary(k.military);
                g.finalizeSpawn(level, level.getCurrentDifficultyAt(gp), MobSpawnType.STRUCTURE, null, null);
                level.addFreshEntityWithPassengers(g);
            }
        } else if (rand.nextFloat() < 0.12F) {
            // иногда в заброшке уже орудует Дигерсто
            DigerstoEntity thief = ModEntities.DIGERSTO.get().create(level.getLevel());
            if (thief != null) {
                BlockPos tp = c0.offset(w / 2, 0, d / 2);
                thief.moveTo(tp.getX() + 0.5D, tp.getY(), tp.getZ() + 0.5D, rand.nextFloat() * 360.0F, 0.0F);
                thief.finalizeSpawn(level, level.getCurrentDifficultyAt(tp), MobSpawnType.STRUCTURE, null, null);
                level.addFreshEntityWithPassengers(thief);
            }
        }
        return true;
    }

    private static Block[] propsFor(SiteKind kind) {
        return switch (kind) {
            case SCHOOL -> new Block[]{Blocks.OAK_SLAB, Blocks.OAK_SLAB, Blocks.BOOKSHELF, Blocks.LECTERN};
            case HOSPITAL, GUARDED_HOSPITAL -> new Block[]{Blocks.WHITE_CARPET, Blocks.WHITE_WOOL, Blocks.CAULDRON, Blocks.LIGHT_GRAY_CARPET};
            case FACTORY -> new Block[]{Blocks.ANVIL, Blocks.FURNACE, Blocks.BARREL, Blocks.CAULDRON, Blocks.HOPPER};
            case SHELTER -> new Block[]{Blocks.BARREL, Blocks.CRAFTING_TABLE, Blocks.LANTERN};
            case FIRE_STATION -> new Block[]{Blocks.BARREL, Blocks.CRAFTING_TABLE, Blocks.RED_CARPET, Blocks.CAULDRON};
            case MILITARY -> new Block[]{Blocks.BARREL, Blocks.CRAFTING_TABLE, Blocks.GRAY_CARPET, Blocks.ANVIL};
        };
    }
}
