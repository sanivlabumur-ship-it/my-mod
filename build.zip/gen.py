import os, json, zlib, struct, random
ROOT = "/home/claude/digersto-mod"
MID = "digersto"
random.seed(7)

def w(path, text):
    p = os.path.join(ROOT, path)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        f.write(text)

def wj(path, obj):
    w(path, json.dumps(obj, ensure_ascii=False, indent=2))

# ---------- tiny PNG canvas ----------
class Img:
    def __init__(s, wd, ht):
        s.w, s.h = wd, ht
        s.p = [[(0, 0, 0, 0)] * wd for _ in range(ht)]
    def rect(s, x0, y0, x1, y1, c):
        for y in range(y0, y1):
            for x in range(x0, x1):
                s.p[y][x] = c
    def px(s, x, y, c):
        if 0 <= x < s.w and 0 <= y < s.h:
            s.p[y][x] = c
    def save(s, path):
        full = os.path.join(ROOT, path)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        raw = b""
        for row in s.p:
            raw += b"\x00" + b"".join(bytes(c) for c in row)
        def chunk(t, d):
            c = struct.pack(">I", len(d)) + t + d
            return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
        png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", s.w, s.h, 8, 6, 0, 0, 0)) \
              + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
        with open(full, "wb") as f:
            f.write(png)

def A(c, a=255): return (c[0], c[1], c[2], a)

# ---------- data ----------
MASKS = [
 ("gp_4","ГП-4","GP-4","SIMPLE"),("gp_5","ГП-5","GP-5","SIMPLE"),("gp_5m","ГП-5М","GP-5M","MILITARY"),
 ("gp_7","ГП-7","GP-7","MILITARY"),("gp_7v","ГП-7В","GP-7V","MILITARY"),("gp_7vm","ГП-7ВМ","GP-7VM","MILITARY"),
 ("gp_9","ГП-9","GP-9","MILITARY"),("gp_21","ГП-21","GP-21","MILITARY"),
 ("pmk","ПМК","PMK","MILITARY"),("pmk_1","ПМК-1","PMK-1","MILITARY"),("pmk_2","ПМК-2","PMK-2","MILITARY"),("pmk_3","ПМК-3","PMK-3","MILITARY"),
 ("shm_41m","ШМ-41М","ShM-41M","MILITARY"),("shs_1","ШС-1","ShS-1","MILITARY"),("pbf","ПБФ","PBF","SIMPLE"),("rpg_67","РПГ-67","RPG-67","MILITARY"),
 ("ip_4","ИП-4","IP-4","ISOLATING"),("ip_5","ИП-5","IP-5","ISOLATING"),("kip_8","КИП-8","KIP-8","ISOLATING"),
 ("pdf_d","ПДФ-Д","PDF-D","SIMPLE"),("pdf_sh","ПДФ-Ш","PDF-Sh","SIMPLE"),
 ("m17","M17","M17","MILITARY"),("m17a1","M17A1","M17A1","MILITARY"),("m17a2","M17A2","M17A2","MILITARY"),
 ("m40","M40","M40","MILITARY"),("m42","M42","M42","MILITARY"),("m45","M45","M45","MILITARY"),
 ("m50","M50","M50","MILITARY"),("m51","M51","M51","MILITARY"),("mcu_2p","MCU-2/P","MCU-2/P","MILITARY"),
 ("mark_iv","Mark IV","Mark IV","SIMPLE"),
]
CONDS = [("NEW","_new","(новый)","(new)"),("NORMAL","","",""),("ROTTEN","_rotten","(гнилой)","(rotten)")]
NIGHT = {"gp_7","gp_7v","gp_7vm","gp_9","gp_21","mcu_2p","m40"}
def country(mid): return "us" if mid.startswith("m") else "su"
TIERS = {"SIMPLE":(107,122,58),"MILITARY":(62,82,48),"ISOLATING":(74,88,104)}

# ---------- MaskType.java ----------
lines = []
for i,(mid,_,_,tier) in enumerate(MASKS):
    lines.append(f'    {mid.upper()}("{mid}", MaskTier.{tier}, {"true" if mid in NIGHT else "false"})' + (",\n" if i < len(MASKS)-1 else ";\n"))
w("src/main/java/com/digersto/item/MaskType.java",
  "package com.digersto.item;\n\n/** Все модели противогазов (СССР/Россия и США). Чтобы добавить новую - допиши строку и ресурсы. */\npublic enum MaskType {\n"
  + "".join(lines) +
  "\n    public final String id;\n    public final MaskTier tier;\n    /** Широкий обзор: даёт ночное зрение, пока надет (не у гнилых). */\n    public final boolean wideView;\n\n    MaskType(String id, MaskTier tier, boolean wideView) {\n        this.id = id;\n        this.tier = tier;\n        this.wideView = wideView;\n    }\n}\n")

# ---------- lang ----------
ru, en = {}, {}
for mid, rn, en_n, tier in MASKS:
    for cname, suf, rs, es in CONDS:
        ru[f"item.{MID}.{mid}{suf}"] = (rn + " " + rs).strip()
        en[f"item.{MID}.{mid}{suf}"] = (en_n + " " + es).strip()
ru.update({
 f"item.{MID}.filter":"Фильтр для противогаза", f"item.{MID}.filter_rotten":"Фильтр для противогаза (гнилой)",
 f"block.{MID}.gas_vent":"Газовый очаг",
 f"item.{MID}.guard_spawn_egg":"Яйцо призыва: ЧОП", f"item.{MID}.police_spawn_egg":"Яйцо призыва: полицейский",
 f"item.{MID}.fbi_spawn_egg":"Яйцо призыва: агент ФБР", f"item.{MID}.digersto_spawn_egg":"Яйцо призыва: Дигерсто",
 f"entity.{MID}.guard":"ЧОП", f"entity.{MID}.police":"Полицейский", f"entity.{MID}.fbi":"Агент ФБР", f"entity.{MID}.digersto":"Дигерсто",
 "itemGroup.digersto":"Дигерсто",
 f"tooltip.{MID}.tier.simple":"Простой: нужен фильтр", f"tooltip.{MID}.tier.military":"Военный: нужен фильтр, прочнее",
 f"tooltip.{MID}.tier.isolating":"Изолирующий: фильтр не нужен, но быстро изнашивается",
 f"message.{MID}.police":"ЧОП вызвал полицию!", f"message.{MID}.fbi":"ЧОП вызвал ФБР!",
 f"message.{MID}.confiscated":"Полиция конфисковала твоё снаряжение!",
 f"message.{MID}.wanted":"Розыск: %s", f"tooltip.{MID}.wide":"Широкий обзор: ночное зрение",
})
en.update({
 f"item.{MID}.filter":"Gas Mask Filter", f"item.{MID}.filter_rotten":"Gas Mask Filter (rotten)",
 f"block.{MID}.gas_vent":"Gas Vent",
 f"item.{MID}.guard_spawn_egg":"Guard Spawn Egg", f"item.{MID}.police_spawn_egg":"Police Officer Spawn Egg",
 f"item.{MID}.fbi_spawn_egg":"FBI Agent Spawn Egg", f"item.{MID}.digersto_spawn_egg":"Digersto Spawn Egg",
 f"entity.{MID}.guard":"Security Guard", f"entity.{MID}.police":"Police Officer", f"entity.{MID}.fbi":"FBI Agent", f"entity.{MID}.digersto":"Digersto",
 "itemGroup.digersto":"Digersto",
 f"tooltip.{MID}.tier.simple":"Simple: needs a filter", f"tooltip.{MID}.tier.military":"Military: needs a filter, more durable",
 f"tooltip.{MID}.tier.isolating":"Isolating: no filter needed, wears out fast",
 f"message.{MID}.police":"The guard called the police!", f"message.{MID}.fbi":"The guard called the FBI!",
 f"message.{MID}.confiscated":"The police confiscated your gear!",
 f"message.{MID}.wanted":"Wanted: %s", f"tooltip.{MID}.wide":"Wide view: night vision",
})
wj(f"src/main/resources/assets/{MID}/lang/ru_ru.json", ru)
wj(f"src/main/resources/assets/{MID}/lang/en_us.json", en)

# ---------- item models ----------
for mid,_,_,_ in MASKS:
    pass
tier_of = {m[0]: m[3] for m in MASKS}
for mid, _, _, tier in MASKS:
    for cname, suf, _, _ in CONDS:
        wj(f"src/main/resources/assets/{MID}/models/item/{mid}{suf}.json",
           {"parent":"minecraft:item/generated","textures":{"layer0":f"{MID}:item/mask_{tier.lower()}_{cname.lower()}_{country(mid)}"}})
for f in ("filter","filter_rotten"):
    wj(f"src/main/resources/assets/{MID}/models/item/{f}.json",
       {"parent":"minecraft:item/generated","textures":{"layer0":f"{MID}:item/{f}"}})
for e in ("guard","police","fbi","digersto"):
    wj(f"src/main/resources/assets/{MID}/models/item/{e}_spawn_egg.json", {"parent":"minecraft:item/template_spawn_egg"})
wj(f"src/main/resources/assets/{MID}/models/item/gas_vent.json", {"parent":f"{MID}:block/gas_vent"})
wj(f"src/main/resources/assets/{MID}/models/block/gas_vent.json", {"parent":"minecraft:block/cube_all","textures":{"all":f"{MID}:block/gas_vent"}})
wj(f"src/main/resources/assets/{MID}/blockstates/gas_vent.json", {"variants":{"":{"model":f"{MID}:block/gas_vent"}}})
wj(f"src/main/resources/data/{MID}/loot_tables/blocks/gas_vent.json",
   {"type":"minecraft:block","pools":[{"rolls":1,"entries":[{"type":"minecraft:item","name":f"{MID}:gas_vent"}],
    "conditions":[{"condition":"minecraft:survives_explosion"}]}]})
wj("src/main/resources/pack.mcmeta", {"pack":{"description":"Digersto","pack_format":15}})

# ---------- textures: item icons ----------
def shade(c, k): return tuple(max(0, min(255, int(v*k))) for v in c)
def mask_icon(base, cond, cty):
    im = Img(16,16)
    col = base
    if cond == "NEW": col = shade(base, 1.25)
    if cond == "ROTTEN": col = (int(base[0]*0.7+40), int(base[1]*0.7+30), int(base[2]*0.5))
    im.rect(4,1,12,12,A(col)); im.rect(3,3,13,10,A(col)); im.rect(5,11,11,13,A(shade(col,0.85)))
    lens = (20,20,24) if cond != "ROTTEN" else (40,50,30)
    im.rect(4,5,7,8,A(lens)); im.rect(9,5,12,8,A(lens))
    im.px(4,5,A((200,220,230))) if cond=="NEW" else None
    im.px(9,5,A((200,220,230))) if cond=="NEW" else None
    im.rect(6,11,10,15,A(shade(col,0.6))); im.rect(7,13,9,14,A(shade(col,0.4)))
    im.rect(3,1,4,3,A(shade(col,0.5))); im.rect(12,1,13,3,A(shade(col,0.5)))
    if cond == "ROTTEN":
        for _ in range(14):
            im.px(random.randint(3,12), random.randint(2,13), A((70+random.randint(0,40),110+random.randint(0,40),40)))
    if cty == "su":
        im.rect(0,13,4,15,A((200,30,30))); im.px(1,13,A((240,200,40)))
    else:
        im.rect(0,13,4,15,A((40,70,160))); im.px(1,13,A((240,240,240)))
    return im
for tier, base in TIERS.items():
    for cname, *_ in CONDS:
        for cty in ("su","us"):
            mask_icon(base, cname, cty).save(f"src/main/resources/assets/{MID}/textures/item/mask_{tier.lower()}_{cname.lower()}_{cty}.png")
def filt(rotten):
    im = Img(16,16); c = (150,150,160) if not rotten else (110,120,70)
    im.rect(4,3,12,13,A(c)); im.rect(5,2,11,3,A(shade(c,0.7))); im.rect(5,13,11,14,A(shade(c,0.7)))
    im.rect(4,7,12,9,A(shade(c,0.6)))
    if rotten:
        for _ in range(12): im.px(random.randint(4,11), random.randint(3,12), A((60,110+random.randint(0,40),40)))
    else:
        im.rect(6,4,7,12,A(shade(c,1.2)))
    return im
filt(False).save(f"src/main/resources/assets/{MID}/textures/item/filter.png")
filt(True).save(f"src/main/resources/assets/{MID}/textures/item/filter_rotten.png")
v = Img(16,16); v.rect(0,0,16,16,A((70,74,78)))
for i in range(2,16,3): v.rect(1,i,15,i+1,A((20,22,24)))
v.rect(0,0,16,1,A((95,100,105))); v.rect(0,15,16,16,A((40,42,44)))
v.save(f"src/main/resources/assets/{MID}/textures/block/gas_vent.png")

# ---------- armor layer textures (64x32) ----------
for tier, base in TIERS.items():
    for cname, *_ in CONDS:
        col = base
        if cname == "NEW": col = shade(base, 1.25)
        if cname == "ROTTEN": col = (int(base[0]*0.7+40), int(base[1]*0.7+30), int(base[2]*0.5))
        im = Img(64,32)
        im.rect(0,0,64,16,A(col))
        im.rect(8,8,16,16,A(col))
        # lenses + canister on the front face (8..15, 8..15)
        im.rect(9,10,11,12,A((15,15,20))); im.rect(13,10,15,12,A((15,15,20)))
        im.rect(11,13,13,16,A(shade(col,0.55)))
        im.rect(8,8,16,9,A(shade(col,0.7)))
        if cname == "ROTTEN":
            for _ in range(40): im.px(random.randint(0,63), random.randint(0,15), A((70,110+random.randint(0,40),40)))
        im.save(f"src/main/resources/assets/{MID}/textures/models/armor/{tier.lower()}_{cname.lower()}_layer_1.png")

# ---------- entity skins (64x64 player layout) ----------
def skin(shirt, pants, extras=None, mask=False, tone=(224,172,140)):
    im = Img(64,64)
    im.rect(0,0,32,16,A(tone))
    im.rect(0,0,32,8,A(shade(tone,0.35)))
    im.rect(16,16,40,32,A(shirt)); im.rect(40,16,56,32,A(shirt)); im.rect(32,48,48,64,A(shirt))
    im.rect(0,16,16,32,A(pants)); im.rect(16,48,32,64,A(pants))
    im.rect(44,28,48,32,A(tone)); im.rect(36,60,40,64,A(tone))
    if mask:
        im.rect(8,8,16,16,A((45,60,40))); im.rect(9,10,11,12,A((10,10,12))); im.rect(13,10,15,12,A((10,10,12)))
        im.rect(11,13,13,16,A((30,40,28)))
    else:
        im.px(10,11,A((20,20,20))); im.px(13,11,A((20,20,20))); im.rect(10,14,14,15,A((120,60,50)))
    if extras: extras(im)
    return im
skin((30,40,80),(20,22,32), lambda im: im.rect(20,20,28,22,A((200,200,60)))).save(f"src/main/resources/assets/{MID}/textures/entity/guard.png")
skin((40,70,140),(25,35,70), lambda im: im.rect(21,21,24,24,A((220,220,230)))).save(f"src/main/resources/assets/{MID}/textures/entity/police.png")
skin((18,18,20),(14,14,16), lambda im: im.rect(20,22,28,24,A((235,200,40)))).save(f"src/main/resources/assets/{MID}/textures/entity/fbi.png")
skin((50,110,60),(50,50,60), mask=True).save(f"src/main/resources/assets/{MID}/textures/entity/digersto.png")

# ---------- loot tables ----------
def entry(name, weight): return {"type":"minecraft:item","name":f"{MID}:{name}","weight":weight}
def table(rmin, rmax, entries):
    return {"type":"minecraft:chest","pools":[{"rolls":{"type":"minecraft:uniform","min":rmin,"max":rmax},"entries":entries}]}
ab, gb, gm = [], [], []
for mid,_,_,tier in MASKS:
    if tier == "SIMPLE":
        ab += [entry(mid+"_rotten",6), entry(mid,3)]
        gb += [entry(mid+"_new",4), entry(mid,3)]
        gm += [entry(mid+"_new",1)]
    elif tier == "MILITARY":
        ab += [entry(mid+"_rotten",1)]
        gb += [entry(mid+"_new",1)]
        gm += [entry(mid+"_new",4), entry(mid,2)]
    else:
        gm += [entry(mid+"_new",1)]
ab += [entry("filter_rotten",10), entry("filter",3)]
gb += [entry("filter",8)]
gm += [entry("filter",10)]
wj(f"src/main/resources/data/{MID}/loot_tables/chests/abandoned.json", table(1,3,ab))
wj(f"src/main/resources/data/{MID}/loot_tables/chests/guarded_basic.json", table(2,4,gb))
wj(f"src/main/resources/data/{MID}/loot_tables/chests/guarded_military.json", table(2,4,gm))

# ---------- worldgen ----------
KINDS = [("school",100),("hospital",110),("factory",120),("shelter",90),("fire_station",200),("military",260),("guarded_hospital",230)]
for k, chance in KINDS:
    wj(f"src/main/resources/data/{MID}/worldgen/configured_feature/{k}.json", {"type":f"{MID}:{k}","config":{}})
    wj(f"src/main/resources/data/{MID}/worldgen/placed_feature/{k}.json", {"feature":f"{MID}:{k}","placement":[
        {"type":"minecraft:rarity_filter","chance":chance},{"type":"minecraft:in_square"},
        {"type":"minecraft:heightmap","heightmap":"WORLD_SURFACE_WG"},{"type":"minecraft:biome"}]})
wj(f"src/main/resources/data/{MID}/forge/biome_modifier/add_sites.json",
   {"type":"forge:add_features","biomes":"#minecraft:is_overworld","features":[f"{MID}:{k}" for k,_ in KINDS],"step":"surface_structures"})

for mid,_,_,_ in MASKS:
    wj(f"src/main/resources/data/{MID}/recipes/repair_{mid}.json", {
        "type":"minecraft:crafting_shapeless","category":"equipment",
        "ingredients":[{"item":f"{MID}:{mid}_rotten"},{"item":"minecraft:iron_ingot"}],
        "result":{"item":f"{MID}:{mid}"}})
wj(f"src/main/resources/data/{MID}/recipes/filter.json", {
    "type":"minecraft:crafting_shaped","category":"misc","pattern":["I","C","I"],
    "key":{"I":{"item":"minecraft:iron_ingot"},"C":{"item":"minecraft:charcoal"}},
    "result":{"item":f"{MID}:filter"}})
wj(f"src/main/resources/data/{MID}/recipes/repair_filter.json", {
    "type":"minecraft:crafting_shapeless","category":"misc",
    "ingredients":[{"item":f"{MID}:filter_rotten"},{"item":"minecraft:charcoal"}],
    "result":{"item":f"{MID}:filter"}})
print("ok", len(MASKS))
